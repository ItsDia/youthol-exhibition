<template>
  <el-container>
    <el-header>
      <h1>图片展示页面</h1>
    </el-header>
    <el-main>
      <el-row :gutter="20">
        <el-col :span="6" v-for="(image, index) in images" :key="index">
          <el-image
              style="width: 100%; height: 200px; object-fit: cover;"
              :src="image.src"
              :preview-src-list="imageList"
              :initial-index="index"
          />
        </el-col>
      </el-row>
    </el-main>
  </el-container>
</template>

<script setup>
import { ref } from 'vue';

const images = ref([
  { src: 'https://via.placeholder.com/300x200?text=Image+1' },
  { src: 'https://via.placeholder.com/300x200?text=Image+2' },
  { src: 'https://via.placeholder.com/300x200?text=Image+3' },
  { src: 'https://via.placeholder.com/300x200?text=Image+4' },
  { src: 'https://via.placeholder.com/300x200?text=Image+5' },
  { src: 'https://via.placeholder.com/300x200?text=Image+6' },
]);

const imageList = images.value.map(image => image.src);
</script>

<style scoped>
h1 {
  text-align: center;
  margin-bottom: 20px;
}
</style>
